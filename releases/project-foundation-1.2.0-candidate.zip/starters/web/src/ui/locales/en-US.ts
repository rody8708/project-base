// SPDX-FileCopyrightText: 2026 Zendrhax LLC
// SPDX-License-Identifier: MPL-2.0
import type { Messages } from './types';

export const enUS: Messages = {
  pageTitle: 'Tasks · Project Base',
  eyebrow: 'REUSABLE WEB FOUNDATION',
  title: 'A clear starting point.',
  introduction: 'A small list that demonstrates a structure you can adapt to your next project.',
  language: 'Language',
  inputLabel: 'New task',
  inputHint: 'Up to 80 Unicode characters. Enter a task on a single line.',
  inputPlaceholder: 'What would you like to do?',
  add: 'Add task',
  working: 'Working…',
  loading: 'Loading tasks…',
  emptyTitle: 'Your list starts here',
  emptyBody: 'Add your first task and check it off when it is done.',
  listLabel: 'Task list',
  pending: 'Pending',
  completed: 'Completed',
  retry: 'Reload list',
  memoryNotice: 'In memory only. Reloading this page deletes the tasks.',
  remoteNotice: 'API mode: data is stored by the backend.',
  architecture: 'One structure, clear responsibilities',
  architectureBody: 'Pure domain rules · Use cases · Memory and interface adapters',
  candidate: 'Replaceable example · 1.1.0-draft.2 · Technical candidate',
  summary: (total, completed) => `${total} total · ${completed} completed`,
  errors: {
    INVALID_TITLE: 'Enter a valid task without line breaks or control characters.',
    TITLE_TOO_LONG: 'The task exceeds the 80-Unicode-character limit.',
    INVALID_ID: 'The task could not be identified. Check the example configuration.',
    INVALID_TIMESTAMP: 'The example clock returned an invalid value.',
    NOT_FOUND: 'The task is no longer available. Reload the list.',
    DUPLICATE_ID: 'The identifier already exists. No additional task was added.',
    STORAGE_UNAVAILABLE: 'The operation could not be confirmed. Reload before repeating it.',
    DEPENDENCY_FAILURE: 'The task could not be prepared. Check the ID generator and clock.',
  },
};
