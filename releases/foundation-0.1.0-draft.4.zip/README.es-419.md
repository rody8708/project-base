# Base para proyectos de software

Versión del borrador: `0.1.0-draft.4`  
Estado: propuesta; no aprobada para adopción estable.  
Idioma: español latinoamericano (`es-419`)  
[Versión en inglés de Estados Unidos](README.en-US.md)

## Propósito y alcance

Esta es la base maestra para que otros proyectos comiencen con fundamentos de programación, reglas explícitas y decisiones justificadas y verificables. Las aplicaciones web, de escritorio (Windows, macOS y Linux) y móviles se construyen fuera de esta base.

La primera entrega es documental: doce áreas de fundamentos, diez reglas, cinco etapas de trabajo, cuatro perfiles orientativos y una plantilla de ocho secciones. No es un estándar exhaustivo de toda la programación ni un conjunto de aplicaciones o arquitecturas ya probadas. Los perfiles ayudan a formular preguntas; no acreditan soporte de plataformas ni sustituyen sus requisitos oficiales al implementar.

La revisión `0.1.0-draft.4` cierra la evaluación documental de los 39 elementos y las condiciones de pruebas, dependencias y compatibilidad. Conserva 97 comprobaciones de modelos, ocho escenarios anteriores y 78 decisiones documentales de aplicabilidad. Incorpora controles de mantenimiento y conservación del paquete, escritos en Markdown. PowerShell se usa para comprobar esta base, no como tecnología impuesta a los futuros proyectos.

No hay publicaciones estables aprobadas. La etiqueta inicial `1.0.0` fue prematura y se corrigió; solo una aprobación explícita del paquete exacto podrá asignar esa versión de publicación. Los encabezados congelados describen el estado al preparar el candidato; la aprobación posterior se conserva externamente, vinculada a su SHA-256.

## Orden de lectura

1. [Entrega preparada y evidencia](docs/release-readiness.es-419.md): cierre de los cinco puntos y decisión de aprobación.
2. [Gobernanza](docs/foundation-governance.es-419.md): estados, conservación, aprobación y adopción.
3. [Aplicabilidad](docs/applicability.es-419.md): alcance inicial, decisiones locales y evaluación de los 39 elementos.
4. [Trazabilidad](docs/traceability.es-419.md): origen, ediciones, apartados y límites del respaldo.
5. [Reglas propuestas](docs/immutable-rules.es-419.md): diez obligaciones con condiciones explícitas.
6. [Fundamentos](docs/programming-fundamentals.es-419.md): contratos, ejemplos, respaldo y límites.
7. [Datos y tiempo](docs/data-and-time.es-419.md): representación, precisión, texto, calendario y duración.
8. [Fallos y recursos](docs/failures-and-resources.es-419.md): propiedad, cancelación, reintentos y recuperación.
9. [Comprobación del núcleo](docs/core-verification.es-419.md): 80 comprobaciones y ocho escenarios anteriores.
10. [Modelos iniciales](docs/fundamentals-verification.es-419.md): 17 comprobaciones y defectos deliberados.
11. [Flujo de desarrollo](docs/development-workflow.es-419.md): trabajo de los proyectos externos.
12. [Perfiles de plataforma](docs/platform-guidelines.es-419.md): orientación sin compatibilidad acreditada.
13. [Plantilla de proyecto](templates/project-brief.es-419.md): decisiones y evidencia de adopción del consumidor.
14. [Controles documentales](docs/document-checks.es-419.md): comprobación repetible de estructura y paridad.
15. [Herramientas de entrega](docs/release-tools.es-419.md): crear, verificar y recuperar el candidato.

## Uso de la base

Antes de adoptar, verificar el paquete contra la identidad de un registro de aprobación confiable, revisar su alcance y registrar la adopción en el proyecto externo. Una copia modificada no se presenta como original. Los detalles propios del consumidor (lenguaje, arquitectura, dependencias, versiones, canales y pruebas reales) se concretan allí; no son aplicaciones pendientes de construir aquí.

Las reglas aprobadas serán obligaciones dentro de su alcance. «No aplica» requiere una condición explícita y justificación verificable, no suspender controles para facilitar una entrega. Recomendaciones y perfiles permiten alternativas justificadas. Los documentos y modelos no garantizan que un producto futuro funcione: sus implementaciones deben comprobarse.

## Idiomas y archivos

Cada documento mantenido tiene archivos independientes `.es-419.md` y `.en-US.md`, en UTF-8, con alcance, obligaciones, identificadores, revisión y estado equivalentes. Ningún idioma prevalece. Los cambios se entregan con su traducción; una discrepancia se resuelve en ambos archivos. El español conserva acentos y signos de apertura, y el inglés usa convenciones de Estados Unidos.

Los enlaces internos apuntan al mismo idioma salvo el enlace a la contraparte. Identificadores, comandos y nombres propios no se traducen cuando eso alteraría su significado. Los idiomas del producto se deciden por separado. Los originales externos que deben permanecer intactos conservan su forma.

Los archivos fuente están en la raíz, `docs` y `templates`. `releases` y `.validation` contienen artefactos generados de mantenimiento, no proyectos consumidores. ZIP y manifiestos JSON son formatos técnicos neutros, no documentos bilingües combinados.

## Estado para decidir

El [registro de entrega](docs/release-readiness.es-419.md) distingue evidencia obtenida, limitaciones y aprobación pendiente. Los registros `.1`, `.2` y `.3` son históricos. Si se solicitan cambios al candidato, se crea otra revisión y se comprueba nuevamente; no se sobrescribe una publicación aprobada.
