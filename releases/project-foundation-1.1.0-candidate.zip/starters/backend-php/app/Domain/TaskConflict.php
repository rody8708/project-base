<?php
declare(strict_types=1);
namespace App\Domain;
final class TaskConflict extends \RuntimeException {}
