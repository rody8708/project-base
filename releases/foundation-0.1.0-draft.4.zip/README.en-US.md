# Software Project Foundation

Draft revision: `0.1.0-draft.4`  
Status: proposal; not approved for stable adoption.  
Language: US English (`en-US`)  
[Latin American Spanish version](README.es-419.md)

## Purpose and Scope

This is the master foundation for other projects to start with programming fundamentals, explicit rules, and justified, verifiable decisions. Web, desktop (Windows, macOS, and Linux), and mobile applications are built outside this foundation.

The first delivery is documentary: twelve fundamental areas, ten rules, five workflow stages, four advisory profiles, and an eight-section template. It is not an exhaustive standard for all programming or a set of already tested applications or architectures. The profiles help frame questions; they do not establish platform support or replace official requirements during implementation.

Revision `0.1.0-draft.4` closes documentary evaluation of all 39 elements and the conditions for testing, dependencies, and compatibility. It retains 97 model checks, eight earlier scenarios, and 78 documentary applicability decisions. It adds maintenance and package-preservation checks written in Markdown. PowerShell is used to check this foundation, not prescribed as future projects' technology.

There are no approved stable releases. The initial `1.0.0` label was premature and corrected; only explicit approval of the exact package may assign that release version. Frozen headers describe the candidate-preparation snapshot; later approval is retained externally, tied to its SHA-256.

## Reading Order

1. [Prepared delivery and evidence](docs/release-readiness.en-US.md): closure of the five points and the approval decision.
2. [Governance](docs/foundation-governance.en-US.md): states, preservation, approval, and adoption.
3. [Applicability](docs/applicability.en-US.md): initial scope, local decisions, and evaluation of all 39 elements.
4. [Traceability](docs/traceability.en-US.md): origin, editions, sections, and support limits.
5. [Proposed rules](docs/immutable-rules.en-US.md): ten obligations with explicit conditions.
6. [Fundamentals](docs/programming-fundamentals.en-US.md): contracts, examples, support, and limits.
7. [Data and time](docs/data-and-time.en-US.md): representation, precision, text, calendars, and duration.
8. [Failures and resources](docs/failures-and-resources.en-US.md): ownership, cancellation, retries, and recovery.
9. [Core verification](docs/core-verification.en-US.md): 80 checks and eight earlier scenarios.
10. [Initial models](docs/fundamentals-verification.en-US.md): 17 checks and deliberate defects.
11. [Development workflow](docs/development-workflow.en-US.md): work in external projects.
12. [Platform profiles](docs/platform-guidelines.en-US.md): guidance without established compatibility.
13. [Project template](templates/project-brief.en-US.md): consumer decisions and adoption evidence.
14. [Document checks](docs/document-checks.en-US.md): repeatable structure and parity verification.
15. [Release tools](docs/release-tools.en-US.md): create, verify, and recover the candidate.

## Using the Foundation

Before adoption, verify the package against the identity in a trusted approval record, review its scope, and record adoption in the external project. An edited copy is not presented as the original. Consumer-specific details (language, architecture, dependencies, versions, channels, and actual tests) are specified there; they are not applications waiting to be built here.

Approved rules will be obligations within their scope. “Not applicable” requires an explicit condition and verifiable justification, not waiving checks to facilitate delivery. Recommendations and profiles allow justified alternatives. Documents and models do not guarantee that a future product works: its implementations must be checked.

## Languages and Files

Every maintained document has separate `.es-419.md` and `.en-US.md` files, in UTF-8, with equivalent scope, obligations, identifiers, revision, and status. Neither language takes precedence. Changes include their translation; discrepancies are resolved in both files. Spanish retains accent marks and opening punctuation, and English follows US conventions.

Internal links point to the same language except for the counterpart link. Identifiers, commands, and proper names are not translated when doing so would change their meaning. Product languages are decided separately. External originals that must remain intact retain their original form.

Source files are at the root and in `docs` and `templates`. `releases` and `.validation` contain generated maintenance artifacts, not consuming projects. ZIP files and JSON manifests are language-neutral technical formats, not combined bilingual documents.

## Decision Status

The [delivery record](docs/release-readiness.en-US.md) distinguishes obtained evidence, limitations, and pending approval. Records `.1`, `.2`, and `.3` are historical. Requested candidate changes produce another revision and renewed checks; an approved release is never overwritten.
